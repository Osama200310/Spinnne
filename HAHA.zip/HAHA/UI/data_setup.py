import sqlite3
import datetime
import os

# Path to the database in the same directory as the script
DB_PATH = os.path.join(os.path.dirname(__file__), 'detections.db')

# Connect to the database (it will be created if it doesn't exist)
conn = sqlite3.connect(DB_PATH)
cursor = conn.cursor()

# Create the detections table
cursor.execute('''
CREATE TABLE IF NOT EXISTS detections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    image_path TEXT NOT NULL,
    address TEXT,
    timestamp DATETIME NOT NULL,
    detection TEXT NOT NULL,
    probability REAL NOT NULL
)
''')

# Clear existing data
cursor.execute('DELETE FROM detections')

# Sample data
# These paths assume an 'outputs' directory at the project root.
sample_data = [
    (
        '../outputs/IMAG0011_yolov8_annotated.jpg',
        '123 Main St, Anytown',
        datetime.datetime.now() - datetime.timedelta(hours=1),
        'bird',
        0.85
    ),
    (
        '../outputs/IMAG0012_yolov8_annotated.jpg',
        '456 Oak Ave, Sometown',
        datetime.datetime.now() - datetime.timedelta(minutes=30),
        'sheep',
        0.92
    ),
    (
        '../outputs/IMAG0013_yolov8_annotated.jpg',
        '789 Pine Ln, Yourtown',
        datetime.datetime.now() - datetime.timedelta(minutes=10),
        'deer',
        0.78
    )
]

# Insert sample data
cursor.executemany('''
INSERT INTO detections (image_path, address, timestamp, detection, probability)
VALUES (?, ?, ?, ?, ?)
''', sample_data)

# Commit changes and close the connection
conn.commit()
conn.close()

print(f"Database '{DB_PATH}' created and populated with sample data.")
