from flask import Flask, jsonify, request, send_file, send_from_directory
import requests
import os
from datetime import datetime

app = Flask(__name__, static_folder='static', static_url_path='/static')
PI_SERVER = "http://10.30.15.157:8080"

@app.route('/')
def serve_index():
    return send_from_directory('', 'index.html')

@app.route('/api/detections', methods=['GET'])
def get_detections():
    try:
        print("Versuche Daten abzurufen von:", f"{PI_SERVER}/api/detections")
        response = requests.get(f"{PI_SERVER}/api/detections")
        print("Status Code:", response.status_code)
        
        if response.status_code == 200:
            data = response.json()
            print("Empfangene Daten:", data)
            
            # Transformiere die Daten in das gewünschte Format
            transformed_data = []
            for item in data:
                # Extrahiere "det" aus dem Dateinamen, falls vorhanden
                detection_type = "Objekt erkannt"
                if "_det." in item['filename']:
                    detection_type = "Detektion"
                
                transformed_item = {
                    'id': item['id'],
                    'image_path': f"{PI_SERVER}{item['url']}",
                    'timestamp': item['saved_at'],
                    'detection_type': detection_type,
                    'probability': float(item['score']) if item['score'] else 0.0,
                    'address': item['filename'].split('_image_')[0]  # Extrahiere ID aus Dateinamen
                }
                transformed_data.append(transformed_item)
            
            print("Transformierte Daten:", transformed_data)
            return jsonify(transformed_data)  # Direkt das Array zurückgeben
            
        else:
            print("Fehler beim Abrufen der Daten. Status:", response.status_code)
            return jsonify({"error": "Fehler beim Abrufen der Daten"}), 500
    except Exception as e:
        print(f"Fehler beim Abrufen der Daten: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/detections/<int:id>', methods=['DELETE'])
def delete_detection(id):
    try:
        # Löschanfrage an Raspberry Pi senden
        response = requests.delete(f"{PI_SERVER}/detections/{id}")
        if response.status_code == 200:
            return jsonify({"success": True})
        else:
            return jsonify({"error": "Fehler beim Löschen"}), 500
    except Exception as e:
        print(f"Fehler beim Löschen: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/uploads/<path:filename>')
def serve_image(filename):
    try:
        # Bild vom Raspberry Pi abrufen
        response = requests.get(f"{PI_SERVER}/uploads/{filename}", stream=True)
        if response.status_code == 200:
            return response.content, 200, {'Content-Type': 'image/jpeg'}
        else:
            return "Bild nicht gefunden", 404
    except Exception as e:
        print(f"Fehler beim Abrufen des Bildes: {e}")
        return "Fehler beim Abrufen des Bildes", 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)