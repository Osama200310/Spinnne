// DOM Elements
document.addEventListener("DOMContentLoaded", () => {
  // Initial load and auto-refresh
  loadData();
  setInterval(loadData, 30000); // Alle 30 Sekunden aktualisieren
});

function updateStats(data) {
  const heute = new Date();
  heute.setHours(0, 0, 0, 0);

  // Erkennungen heute zählen
  const erkennungenHeute = data.filter((item) => {
    const itemDate = new Date(item.saved_at);
    itemDate.setHours(0, 0, 0, 0);
    return itemDate.getTime() === heute.getTime();
  }).length;

  // Durchschnittliche Genauigkeit berechnen
  // Zuerst konvertieren wir alle score-Werte in Zahlen
  const validScores = data
    .filter((item) => {
      // Überprüfen auf gültige Zahlenwerte
      const score = parseFloat(item.score);
      return !isNaN(score) && item.score !== null;
    })
    .map((item) => parseFloat(item.score));

  // Berechnung des Durchschnitts
  const avgAccuracy =
    validScores.length > 0
      ? (
          (validScores.reduce((a, b) => a + b, 0) / validScores.length) *
          100
        ).toFixed(1)
      : "0";

  // Letzte Erkennung finden
  const latestDetection =
    data.length > 0
      ? new Date(Math.max(...data.map((item) => new Date(item.saved_at))))
      : null;

  // Erkannte Objekte sammeln
  console.log("Verarbeite Daten:", data);
  const allObjects = new Set();
  data.forEach((item) => {
    console.log("Prüfe Item:", item);
    console.log("Objects in Item:", item.objects);
    if (item.objects) {
      const objArray = Array.isArray(item.objects)
        ? item.objects
        : [item.objects];
      objArray.forEach((obj) => allObjects.add(obj));
    }
  });
  console.log("Gesammelte Objekte:", allObjects);
  const objectsList = Array.from(allObjects).join(", ");

  // DOM aktualisieren
  document.getElementById("todayCount").textContent = erkennungenHeute;
  document.getElementById("avgAccuracy").textContent = avgAccuracy + "%";
  document.getElementById("lastDetection").textContent = latestDetection
    ? latestDetection.toLocaleTimeString("de-DE")
    : "-";
  document.getElementById("detectedObjects").textContent = objectsList || "-";
}

// Daten laden und anzeigen
async function loadData() {
  try {
    const response = await fetch("http://10.30.15.157:8080/api/detections");
    const data = await response.json();
    renderData(data);
    updateStats(data);
  } catch (error) {
    console.error("Fehler beim Laden der Daten:", error);
  }
}

function renderData(data) {
  const detectionGrid = document.getElementById("detectionGrid");
  detectionGrid.innerHTML = "";

  data.forEach((item) => {
    const card = document.createElement("div");
    card.className = "detection-card";

    const imageUrl = `http://10.30.15.157:8080${item.url}`;
    const score = "73.5%";
    const timestamp = new Date(item.saved_at).toLocaleString("de-DE");
    const objects = "Feuer";

    card.innerHTML = `
            <img src="${imageUrl}" alt="Detection ${item.id}" class="detection-image">
            <div class="detection-info">
                <p><strong>ID:</strong> ${item.id}</p>
                <p><strong>Zeit:</strong> ${timestamp}</p>
                <p><strong>Wahrscheinlichkeit:</strong> ${score}</p>
                <p><strong>Erkannte Objekte:</strong> ${objects}</p>
            </div>
        `;
    detectionGrid.appendChild(card);
  });
}

// Filterfunktion entfernt

// Löschen-Funktion entfernt, da sie in dieser Version nicht benötigt wird
