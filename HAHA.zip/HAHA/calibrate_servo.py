import time
import board
import busio
from adafruit_pca9685 import PCA9685
from adafruit_motor import servo

i2c = busio.I2C(board.SCL, board.SDA)
pca = PCA9685(i2c)
pca.frequency = 50

channel = int(input("Welchen Kanal kalibrieren (0–15)? "))
s = servo.Servo(pca.channels[channel], min_pulse=500, max_pulse=2500)

print("Drücke Enter, um den Servo auf 0°, 90°, 180° zu bewegen.")
for angle in [0, 90, 180]:
    input(f"{angle}° – Enter zum Bewegen")
    s.angle = angle
    time.sleep(1)

print("\nPasse jetzt min_pulse / max_pulse an und beobachte den Unterschied:")
while True:
    min_p = int(input("Neuer min_pulse (500–800, 0=beenden): "))
    if min_p == 0:
        break
    max_p = int(input("Neuer max_pulse (2200–2600): "))
    s = servo.Servo(pca.channels[channel], min_pulse=min_p, max_pulse=max_p)
    s.angle = 90
    print(f"Teste Mitte mit {min_p}/{max_p}")
    time.sleep(1)
